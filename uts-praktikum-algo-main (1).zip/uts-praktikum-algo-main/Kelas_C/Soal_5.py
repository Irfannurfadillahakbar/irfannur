a = "Hello, World!"
print(a[2])               
print(len(a))             
print(a.upper())           
print(a.lower())          
print(a.replace("H", "G")) 
print(a[2:5])             
print(a[7:10])            
print(a.count("O"))       
hasilnya:
l
13
HELLO, WORLD!
hello, world!
Gello, World!
llo
Wor
2
