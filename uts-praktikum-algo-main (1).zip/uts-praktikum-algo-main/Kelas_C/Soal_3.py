soal_3.py 
input("Masukan kata pertama:") 
input("Masukan kata kedua:")
gabungan = Muhammad + Kasyfirrabbani 
print(f"Hasil penggabungan:{MuhammadKasyfirrabbani}")
hasilnya:
Masukan kata pertama:Muhammad
Masukan kata kedua:Kasyfirrabbani
Hasil penggabungan:MuhammadKasyfirrabbani

