soal_4.py
a = "Muhammad_Kasyfirrabbani" 
print(a[:8]) print(a[9:23])
print(a.lower())
print(a.upper())
print(len(a))
hasilnya:
Muhammad
Kasyfirrabbani
muhammad_kasyfiirabbani
MUHAMMAD_KASYFIRRABBANI
23

