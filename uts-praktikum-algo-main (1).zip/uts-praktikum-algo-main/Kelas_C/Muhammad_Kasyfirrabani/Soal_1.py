soal_1.py
panjang = float (input("Masukan panjang:")) 
lebar = float (input ("Masukan lebar:")) 
luas = panjang * lebar keliling = 2 * (panjang + lebar)
print(f"luas persegi panjang = {luas}")
print(f"keliling persegi panjang = {keliling}")
hasilnya: 
masukan panjang :20
masukan lebar :15
luas persegi panjang = 300.0 
keliling persegi panjang = 70.0

